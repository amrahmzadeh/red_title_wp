# Plugin Name: Red Title Addon for Wordpress
# Description: A simple and useful WordPress plugin that allows you to add custom red text to your post titles.
# Version: 1.0
# Author: Amrah Movsumzade

# Features
✅ Add custom red text to post titles
✅ Visible on both homepage and single post pages
✅ Works on category and archive pages
✅ Appears in search results
✅ Elegant appearance with Montserrat font family
✅ Responsive design
✅ Easy management from admin panel
✅ Security controls included