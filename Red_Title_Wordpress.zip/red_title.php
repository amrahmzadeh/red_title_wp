<?php
/*
Plugin Name: Red Title Addon for Wordpress
Description: Allows you to add custom text in red next to the post title
Version: 1.1
Author: Amrah Movsumzade
*/

// Prevent direct access from outside WordPress
if (!defined('ABSPATH')) {
    exit;
}

class RedTitleAddon {
    
    public function __construct() {
        add_action('init', array($this, 'init'));
    }
    
    public function init() {
        // Add meta box in admin panel
        add_action('add_meta_boxes', array($this, 'add_meta_box'));
        
        // Save custom field when post is saved
        add_action('save_post', array($this, 'save_custom_field'));
        
        // Modify title - both on list and single pages with higher priority
        add_filter('the_title', array($this, 'modify_title'), 100, 2);
        
        // Additional hooks for better compatibility
        add_filter('wp_title', array($this, 'modify_wp_title'), 10, 2);
        add_filter('document_title_parts', array($this, 'modify_document_title'));
        
        // Add CSS with higher priority
        add_action('wp_head', array($this, 'add_css'), 999);
        
        // Alternative method using content filters
        add_filter('the_content', array($this, 'check_and_add_debug'));
    }
    
    // Debug function to check if plugin is working
    public function check_and_add_debug($content) {
        if (is_single() && in_the_loop() && is_main_query()) {
            global $post;
            $red_text = get_post_meta($post->ID, '_red_text', true);
            if (!empty($red_text)) {
                // Add a debug comment
                $content = '<!-- Red Title Plugin Active: ' . esc_html($red_text) . ' -->' . $content;
            }
        }
        return $content;
    }
    
    // Meta box addition function
    public function add_meta_box() {
        add_meta_box(
            'red_text_meta_box',
            'Red Title Text',
            array($this, 'meta_box_content'),
            'post',
            'normal',
            'high'
        );
        
        // Also add to pages if needed
        add_meta_box(
            'red_text_meta_box_page',
            'Red Title Text',
            array($this, 'meta_box_content'),
            'page',
            'normal',
            'high'
        );
    }
    
    // Meta box content
    public function meta_box_content($post) {
        // Add nonce for security
        wp_nonce_field('red_text_nonce_action', 'red_text_nonce');
        
        // Get current value
        $red_text = get_post_meta($post->ID, '_red_text', true);
        
        echo '<table class="form-table">';
        echo '<tr>';
        echo '<th><label for="red_text">Red Text:</label></th>';
        echo '<td>';
        echo '<input type="text" id="red_text" name="red_text" value="' . esc_attr($red_text) . '" size="50" />';
        echo '<p class="description">red label text</p>';
        echo '</td>';
        echo '</tr>';
        echo '</table>';
    }
    
    // Custom field saving function
    public function save_custom_field($post_id) {
        // Check for autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        // Nonce verification
        if (!isset($_POST['red_text_nonce']) || 
            !wp_verify_nonce($_POST['red_text_nonce'], 'red_text_nonce_action')) {
            return;
        }
        
        // User permission check
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Save data
        if (isset($_POST['red_text'])) {
            $red_text = sanitize_text_field($_POST['red_text']);
            if (!empty($red_text)) {
                update_post_meta($post_id, '_red_text', $red_text);
            } else {
                delete_post_meta($post_id, '_red_text');
            }
        }
    }
    
    // Main title modification function
    public function modify_title($title, $post_id = null) {
        // Don't run in admin panel or feeds
        if (is_admin() || is_feed()) {
            return $title;
        }
        
        // Get post ID if not provided
        if (!$post_id) {
            global $post;
            if (isset($post) && is_object($post)) {
                $post_id = $post->ID;
            } else {
                return $title;
            }
        }
        
        // Check if it's a valid post
        if (!$post_id || !is_numeric($post_id)) {
            return $title;
        }
        
        // Apply to both posts and pages
        $post_type = get_post_type($post_id);
        if (!in_array($post_type, array('post', 'page'))) {
            return $title;
        }
        
        $red_text = get_post_meta($post_id, '_red_text', true);
        
        if (!empty($red_text)) {
            // Make sure we don't add it multiple times
            if (strpos($title, 'red-title-text') === false) {
                $title = $title . ' <span class="red-title-text">' . esc_html($red_text) . '</span>';
            }
        }
        
        return $title;
    }
    
    // Alternative method for wp_title
    public function modify_wp_title($title, $sep = '') {
        if (is_single() || is_page()) {
            global $post;
            if (isset($post) && is_object($post)) {
                $red_text = get_post_meta($post->ID, '_red_text', true);
                if (!empty($red_text)) {
                    $title = $title . ' ' . $red_text;
                }
            }
        }
        return $title;
    }
    
    // For newer WordPress versions
    public function modify_document_title($title_parts) {
        if (is_single() || is_page()) {
            global $post;
            if (isset($post) && is_object($post)) {
                $red_text = get_post_meta($post->ID, '_red_text', true);
                if (!empty($red_text) && isset($title_parts['title'])) {
                    $title_parts['title'] = $title_parts['title'] . ' ' . $red_text;
                }
            }
        }
        return $title_parts;
    }
    
    // CSS addition function
    public function add_css() {
        echo '<style type="text/css">
            @import url("https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600;700;900&display=swap");
            
            .red-title-text {
                color: #ff0000 !important;
                font-family: "Montserrat", sans-serif !important;
                font-weight: 600 !important;
                letter-spacing: 0.1em !important;
                margin-left: 5px !important;
                display: inline !important;
            }
            
            /* Title içindeki red text için ek stiller */
            h1 .red-title-text,
            h2 .red-title-text,
            h3 .red-title-text,
            h4 .red-title-text,
            h5 .red-title-text,
            h6 .red-title-text,
            .entry-title .red-title-text,
            .post-title .red-title-text,
            .page-title .red-title-text {
                font-size: inherit !important;
                vertical-align: baseline !important;
                line-height: inherit !important;
                color: #ff0000 !important;
            }
            
            /* Farklı sayfa türleri için */
            .home .red-title-text,
            .archive .red-title-text,
            .category .red-title-text,
            .search .red-title-text,
            .single .red-title-text {
                font-size: inherit !important;
                line-height: inherit !important;
                color: #ff0000 !important;
            }
            
            /* Link içindeki red text */
            a .red-title-text {
                color: #ff0000 !important;
            }
            
            a:hover .red-title-text {
                color: #cc0000 !important;
            }
        </style>';
    }
}

// Start the plugin
new RedTitleAddon();

// Cleanup when plugin is deactivated
register_deactivation_hook(__FILE__, 'red_text_deactivate');

function red_text_deactivate() {
    // Optional: Delete meta data when plugin is removed
    // global $wpdb;
    // $wpdb->delete($wpdb->postmeta, array('meta_key' => '_red_text'));
}

// Activation hook for debugging
register_activation_hook(__FILE__, 'red_text_activate');

function red_text_activate() {
    // Create a test option to verify plugin is working
    update_option('red_title_addon_activated', time());
}
?>